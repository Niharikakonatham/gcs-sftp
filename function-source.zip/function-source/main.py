
import json

from google.cloud import storage
from google.cloud import secretmanager

#this is the bucket from storage bucket.Good to take it from env varible

bucket_name = "storage_project_bucket" #this is the bucket from storage bucket.Good to take it from env varible
prefix="20221006/"   #this is the prefix from storage bucket.Good to take it from env varible
project_number="project_number"  #Projectnumber where your service account key file is stored in secret manager. In our case it is compute project.
secret_id="secret_id" #this is the id of service account key which is stored in secret manager .Good to take it from env varible



#bucket_name=os.environ.get('bucket_name', 'storage_project_bucket')
#prefix=os.environ.get('prefix', 'Source_prefix is not present')
#project_number=os.environ.get('project_number', 'project_number is not present')
#secret_id=os.environ.get('secret_id', 'secret_id is not present')


class CloudSecret:
    """
    This class wraps the functionality of the GCP secret manager
    Note: DO NOT PRINT/LOG secret. It may result in a security threat!
    """
    def __init__(self, project_number, secret_id):
        self._secret_path = f'projects/{project_number}/secrets/{secret_id}/versions/latest'
        self._secret = self._get_cloud_secret()

    def _get_cloud_secret(self):
        secrets = secretmanager.SecretManagerServiceClient()
        return secrets.access_secret_version(request={"name": self._secret_path}).payload.data.decode("utf-8")

    def get_secret_value(self):
        return self._secret



def list_blobs(gcs_client):
    bucket = gcs_client.get_bucket(bucket_name)
    blobs = list(bucket.list_blobs(prefix=prefix))
    list_of_file=[]
    for name in blobs:
        if name.name !=prefix:
            print(name.name)
            list_of_file.append(name.name)
    return list_of_file

def read_from_gcs(gcs_client,bucket, file_name):
    bucket = gcs_client.get_bucket(bucket)
    blob = bucket.blob(file_name)
    if blob.exists():
        print("file downloading started")
        return blob.download_to_filename("/tmp/"+file_name.replace('/','_'))
        #return blob.download_to_filename( file_name.replace('/','_'))
    return None

def read_bytes_from_gcs(gcs_client,bucket, file_name):
    bucket = gcs_client.get_bucket(bucket)
    blob = bucket.blob(file_name)
    if blob.exists():
        return blob.download_as_string()
    return None
    
    
def upload_to_outbound_sftp():
    #TO-DO
    pass

def main(request):
    request_json = request.get_json()
    response = CloudSecret(project_number, secret_id)
    key = response.get_secret_value()
    json_data_dict = json.loads(key)
    gcs = storage.Client().from_service_account_info(json_data_dict)
    list_of_file=list_blobs(gcs)
    for file in list_of_file:
        read_from_gcs(gcs,bucket_name,file)
    return f'file downloaded successfully'