import base64
import json
import pysftp
from google.cloud import storage
from google.cloud import secretmanager

# this is the bucket from storage bucket.Good to take it from env varible

bucket_name = "storage_project_bucket"  # this is the bucket from storage bucket.Good to take it from env varible
prefix = "20221006/"  # this is the prefix from storage bucket.Good to take it from env varible
project_number = "project_number"  # Projectnumber where your service account key file is stored in secret manager. In our case it is compute project.
secret_id = "secret_id"  # this is the id of service account key which is stored in secret manager .Good to take it from env varible


# bucket_name=os.environ.get('bucket_name', 'storage_project_bucket')
# prefix=os.environ.get('prefix', 'Source_prefix is not present')
# project_number=os.environ.get('project_number', 'project_number is not present')
# secret_id=os.environ.get('secret_id', 'secret_id is not present')


class CloudSecret:
    """
    This class wraps the functionality of the GCP secret manager
    Note: DO NOT PRINT/LOG secret. It may result in a security threat!
    """

    def __init__(self, project_number, secret_id):
        self._secret_path = f'projects/{project_number}/secrets/{secret_id}/versions/latest'
        self._secret = self._get_cloud_secret()

    def _get_cloud_secret(self):
        secrets = secretmanager.SecretManagerServiceClient().from_service_account_json('sims-vs-api-sa.json')
        return secrets.access_secret_version(request={"name": self._secret_path}).payload.data.decode("utf-8")

    def get_secret_value(self):
        return self._secret


def list_blobs(gcs_client):
    bucket = gcs_client.get_bucket(bucket_name)
    blobs = list(bucket.list_blobs(prefix=prefix))
    list_of_file = []
    for name in blobs:
        if name.name != prefix:
            print(name.name)
            list_of_file.append(name.name)
    return list_of_file


def read_from_gcs(gcs_client, bucket, file_name):
    bucket = gcs_client.get_bucket(bucket)
    blob = bucket.blob(file_name)
    if blob.exists():
        print("file downloading started")
        return blob.download_to_filename("/tmp/" + file_name.replace('/', '_'))
        # return blob.download_to_filename( file_name.replace('/','_'))
    return None


def read_bytes_from_gcs(gcs_client, bucket, file_name):
    bucket = gcs_client.get_bucket(bucket)
    blob = bucket.blob(file_name)
    if blob.exists():
        return blob.download_as_string()
    return None


def upload_to_outbound_sftp(gcs, bucket_name, file_name):
    ftp_host = None
    ftp_user = None
    ftp_pass = None
    ftp_port = 22
    destination_ftp_site=ftp_host
    source_bucket=bucket_name
    destination_file_path = "/tmp/"+file_name.split("/")[1] # change as per your required path
    print('Start uploading from {}/{} to {}/{}'.format(source_bucket, file_name, destination_ftp_site,
                                                         destination_file_path))
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    sftp = pysftp.Connection(ftp_host, port=ftp_port, username=ftp_user, password=ftp_pass, cnopts=cnopts)
    data = read_bytes_from_gcs(gcs,source_bucket, file_name)
    f = sftp.open(destination_file_path, 'wb')
    try:
        f.write(data)
        f.flush()
    finally:
        f.close()
    if sftp != None:
        sftp.close()
        sftp = None

    print('Upload completed from {}/{} to {}/{}'.format(source_bucket, file_name, destination_ftp_site,
                                                           destination_file_path))


def main(event, context):
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print(pubsub_message)
    response = CloudSecret(project_number, secret_id)
    key = response.get_secret_value()
    json_data_dict = json.loads(key)
    gcs = storage.Client().from_service_account_info(json_data_dict)
    bucket_name=pubsub_message["bucket"]
    file_name=pubsub_message["name"]
    upload_to_outbound_sftp(gcs,bucket_name,file_name=file_name)

    return f'file uploaded On SFTP server successfully'



#
# s={
# "kind": "storage#object",
#  "id": "sims_qa_export/20221006/bquxjob_1c4d83e7_1833262a228.csv/1665145790944357",
#  "selfLink": "https://www.googleapis.com/storage/v1/b/ssample_bucket/o/20221006%2Fbquxjob_1c4d83e7_1833262a228.csv.xlsx",
#  "name": "20221006/bquxjob_1c4d83e7_1833262a228.csv",
#  "bucket": "sample_bucket",
#  "generation": "1665145790944357",
#  "metageneration": "1",
#  "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
#  "timeCreated": "2022-10-07T12:29:51.007Z",
#  "updated": "2022-10-07T12:29:51.007Z",
#  "storageClass": "STANDARD",
#  "timeStorageClassUpdated": "2022-10-07T12:29:51.007Z",
#  "size": "5596",
#  "md5Hash": "N8/DzzXZiVGzYZJvj2JtxA==",
#  "mediaLink": "https://storage.googleapis.com/download/storage/v1/b/sample_bucket/o/20221006%2Fbquxjob_1c4d83e7_1833262a228.csv?generation=1665145790944357&alt=media",
#  "crc32c": "B7ulQw==",
#  "etag": "COWo+bqPzvoCEAE="
#  }

